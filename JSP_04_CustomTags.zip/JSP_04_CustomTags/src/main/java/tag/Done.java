package tag;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class Done extends TagSupport{

	@Override
	public int doStartTag() throws JspException {
		
		try {
			JspWriter out = pageContext.getOut();
			out.print("<h1>Checking is Done<br>All set...</h1>");
			
		}catch(Exception e)
		{
			e.printStackTrace();
			
		}
		return SKIP_BODY;
	}
	
}
